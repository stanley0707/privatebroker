from os.path import join, dirname
from setuptools import setup, find_packages


PACKAGE = find_packages()
NAME = "privatebroker"
DESCRIPTION = ""
AUTHOR = "Stas Shilov"
AUTHOR_EMAIL = "shilowstanisalw@gamail.com"
URL = "https://github.com/stanley0707/privatebroker.git"
VERSION = "1.0"
 
setup(
	name=NAME,
	version=VERSION,
	description=DESCRIPTION,
	long_description=open(join(dirname(__file__), 'README.txt')).read(),
	author=AUTHOR,
	author_email=AUTHOR_EMAIL,
	license="MIT",
	url=URL,
	packages=PACKAGE,
	classifiers=[
		"Intended Audience :: Developers",
		"License :: MIT License",
		"Operating System :: OS Independent",
		"Programming Language :: Python",
	],
	zip_safe=False,
)